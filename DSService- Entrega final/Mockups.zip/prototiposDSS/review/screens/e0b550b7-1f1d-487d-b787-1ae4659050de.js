var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-e0b550b7-1f1d-487d-b787-1ae4659050de" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Registro" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e0b550b7-1f1d-487d-b787-1ae4659050de-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/e0b550b7-1f1d-487d-b787-1ae4659050de-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/e0b550b7-1f1d-487d-b787-1ae4659050de-1622382714847-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="490.0px" datasizeheight="515.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="490.0px" datasizeheight="603.0px" datasizewidthpx="490.0000000000001" datasizeheightpx="603.0000000000001" dataX="395.0" dataY="62.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="360.0px" datasizeheight="38.0px" dataX="460.0" dataY="610.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">&iquest;Tienes una cuenta? </span><span id="rtr-s-Paragraph_1_1">Inicia sesi&oacute;n</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer mouseenter mouseleave click commentable non-processed" customid="Rectangle_2"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="560.0" dataY="534.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0">E N T R A R</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_4" class="pie password firer commentable non-processed" customid="password"  datasizewidth="360.0px" datasizeheight="48.0px" dataX="460.0" dataY="448.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Tel&eacute;fono"/></div></div></div></div></div>\
        <div id="s-Input_3" class="pie number text firer commentable non-processed" customid="telefono"  datasizewidth="360.0px" datasizeheight="48.0px" dataX="460.0" dataY="378.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div>  </div></div></div>\
        <div id="s-Input_1" class="pie text firer commentable non-processed" customid="nombre"  datasizewidth="360.0px" datasizeheight="48.0px" dataX="460.0" dataY="308.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Correo electr&oacute;nico"/></div></div>  </div></div></div>\
        <div id="s-Input_2" class="pie email text firer commentable non-processed" customid="correo"  datasizewidth="360.0px" datasizeheight="48.0px" dataX="460.0" dataY="238.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="email"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre"/></div></div>  </div></div></div>\
        <div id="s-Text_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="193.0px" datasizeheight="49.0px" dataX="543.0" dataY="161.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0">Registrarse</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="logo" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="32.8px" datasizeheight="53.5px" dataX="566.0" dataY="89.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/7ca866c4-2512-4d45-bbda-311d2b36a629.png" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="169.0px" datasizeheight="31.0px" dataX="604.0" dataY="106.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">DSServices</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="138.0px" datasizeheight="51.0px" dataX="565.0" dataY="90.0"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
        <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="80.0px" datasizeheight="17.0px" dataX="664.0" dataY="612.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;