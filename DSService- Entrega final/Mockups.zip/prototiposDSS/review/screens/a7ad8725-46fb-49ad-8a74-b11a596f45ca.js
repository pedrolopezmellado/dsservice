var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-a7ad8725-46fb-49ad-8a74-b11a596f45ca" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="aboutUsRegistrado" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a7ad8725-46fb-49ad-8a74-b11a596f45ca-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/a7ad8725-46fb-49ad-8a74-b11a596f45ca-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/a7ad8725-46fb-49ad-8a74-b11a596f45ca-1622382714847-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_6" class="pie image firer click ie-background commentable non-processed" customid="Image 6"   datasizewidth="69.3px" datasizeheight="113.8px" dataX="512.0" dataY="45.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e7869fa8-b79b-4153-8178-c737c87de940.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="169.0px" datasizeheight="60.0px" dataX="599.0" dataY="80.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">DSServices</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="937.0px" datasizeheight="258.0px" dataX="114.0" dataY="309.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Profesor:</span><span id="rtr-s-Paragraph_1_1"> </span><span id="rtr-s-Paragraph_1_2">V&iacute;ctor Manuel S&aacute;nchez Cartagena<br /></span><span id="rtr-s-Paragraph_1_3"><br /></span><span id="rtr-s-Paragraph_1_4">Nombre del proyecto:</span><span id="rtr-s-Paragraph_1_5"> </span><span id="rtr-s-Paragraph_1_6">DSServices<br /></span><span id="rtr-s-Paragraph_1_7"><br /></span><span id="rtr-s-Paragraph_1_8">Integrantes del grupo:<br /></span><span id="rtr-s-Paragraph_1_9"> &nbsp; &nbsp; &nbsp;<br /> &nbsp; &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_1_10">Jos&eacute; Alberola Torres</span><span id="rtr-s-Paragraph_1_11"> &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_1_12">jat18@gcloud.ua.es<br /></span><span id="rtr-s-Paragraph_1_13"> &nbsp; &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_1_14">Aaron Gimenez Mendez</span><span id="rtr-s-Paragraph_1_15"> &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_1_16">agm343@gcloud.ua.es<br /></span><span id="rtr-s-Paragraph_1_17"> &nbsp; &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_1_18">Pedro L&oacute;pez Mellado</span><span id="rtr-s-Paragraph_1_19"> &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_1_20">plm59@gcloud.ua.es<br /></span><span id="rtr-s-Paragraph_1_21"> &nbsp; &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_1_22">Dar&iacute;o Guerrero Montero &nbsp;</span><span id="rtr-s-Paragraph_1_23"> &nbsp;</span><span id="rtr-s-Paragraph_1_24">dgm94@gcloud.ua.es</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="391.6px" datasizeheight="39.0px" dataX="114.0" dataY="217.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Dise&ntilde;o de sistemas software</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="937.0px" datasizeheight="75.0px" dataX="114.0" dataY="649.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Este proyecto se ha realizado para la asignatura de Dise&ntilde;o de Sistemas Software. La p&aacute;gina se basa en un sistema de compra-venta de servicios. Un usuario puede reservar servicios y publicar los suyos propios y adicionalmente hay un rol de administrador para gestionar el sistema.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="109.3px" datasizeheight="27.0px" dataX="114.0" dataY="612.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Descripci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="173.0px" datasizeheight="189.0px" datasizewidthpx="173.0" datasizeheightpx="189.0" dataX="-945.0" dataY="305.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="173.0px" datasizeheight="189.0px" datasizewidthpx="173.0" datasizeheightpx="189.0" dataX="-703.0" dataY="305.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="173.0px" datasizeheight="189.0px" datasizewidthpx="173.0" datasizeheightpx="189.0" dataX="-460.0" dataY="305.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="173.0px" datasizeheight="189.0px" datasizewidthpx="173.0" datasizeheightpx="189.0" dataX="-217.0" dataY="305.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="232.5px" datasizeheight="29.0px" dataX="516.2" dataY="787.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">D&eacute;janos tu comentario </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="comentario1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Comentario" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="667.0px" datasizeheight="92.0px" datasizewidthpx="667.0" datasizeheightpx="91.99999999999983" dataX="299.0" dataY="1145.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_5_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="667.0px" datasizeheight="92.0px" dataX="299.0" dataY="1145.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">Lo recomiendo, lo volver&iacute;a a contratar.</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_6" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="133.0px" datasizeheight="32.0px" dataX="299.0" dataY="1103.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">Dar&iacute;o</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="comentario2" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Comentario" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="667.0px" datasizeheight="92.0px" datasizewidthpx="667.0" datasizeheightpx="91.99999999999983" dataX="299.0" dataY="1304.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_6_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_7" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="667.0px" datasizeheight="92.0px" dataX="299.0" dataY="1304.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_7_0">Est&aacute; bastante bien. John kiss es un verdadero profesional.</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_8" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="133.0px" datasizeheight="32.0px" dataX="299.0" dataY="1262.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">Pedro</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 1"   datasizewidth="308.0px" datasizeheight="349.0px" datasizewidthpx="307.9999999999998" datasizeheightpx="349.0" dataX="-105.0" dataY="1121.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie textarea firer commentable non-processed" customid="Input 1"  datasizewidth="684.5px" datasizeheight="107.0px" dataX="298.4" dataY="839.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder="Lo recomiendo, lo volver&iacute;a a contratar."></textarea></div></div></div>\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer mouseenter mouseleave click commentable non-processed" customid="Rectangle_2"   datasizewidth="95.2px" datasizeheight="35.2px" datasizewidthpx="95.20765027322409" datasizeheightpx="35.20625000000007" dataX="592.4" dataY="969.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0">E N V I A R</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_9" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 1"   datasizewidth="55.2px" datasizeheight="189.0px" datasizewidthpx="55.19270706176766" datasizeheightpx="189.0" dataX="76.0" dataY="1295.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="932.0px" datasizeheight="1.0px" datasizewidthpx="932.0" datasizeheightpx="1.0" dataX="174.0" dataY="1059.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 1" d="M 0.0 0.5 L 932.0 0.5"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Paragraph_12" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="104.0px" datasizeheight="27.0px" dataX="114.0" dataY="264.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0">2020-2021</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;