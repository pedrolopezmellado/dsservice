var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-997cefd9-ebbc-41db-b6e0-eef0bf974324" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="homeAdministrador" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/997cefd9-ebbc-41db-b6e0-eef0bf974324-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/997cefd9-ebbc-41db-b6e0-eef0bf974324-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/997cefd9-ebbc-41db-b6e0-eef0bf974324-1622382714847-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed" customid="Image 6"   datasizewidth="69.3px" datasizeheight="113.8px" dataX="88.0" dataY="35.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e7869fa8-b79b-4153-8178-c737c87de940.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="169.0px" datasizeheight="60.0px" dataX="175.0" dataY="70.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">DSServices</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="72.1px" datasizeheight="72.1px" datasizewidthpx="72.07976653696505" datasizeheightpx="72.07976653696493" dataX="1153.0" dataY="52.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="36.03988326848253" cy="36.03988326848246" rx="36.03988326848253" ry="36.03988326848246">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="36.03988326848253" cy="36.03988326848246" rx="36.03988326848253" ry="36.03988326848246">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="631.0px" datasizeheight="43.0px" >\
        <div id="s-Rectangle_5" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_5"   datasizewidth="181.7px" datasizeheight="73.5px" datasizewidthpx="181.72500453943428" datasizeheightpx="73.45400936310719" dataX="655.0" dataY="268.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0">Categor&iacute;as</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_8" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_8"   datasizewidth="181.7px" datasizeheight="73.5px" datasizewidthpx="181.7250045394345" datasizeheightpx="73.45400936310719" dataX="443.0" dataY="268.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_8_0">Usuarios</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_9" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_8"   datasizewidth="181.7px" datasizeheight="73.5px" datasizewidthpx="181.72500453943428" datasizeheightpx="73.45400936310728" dataX="655.0" dataY="370.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_9_0">Disputas Pendientes</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_5"   datasizewidth="181.7px" datasizeheight="73.5px" datasizewidthpx="181.72500453943428" datasizeheightpx="73.45400936310728" dataX="443.0" dataY="370.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0">Servicios</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_8" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="106.5px" datasizeheight="33.5px" dataX="1004.6" dataY="71.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Cerrar sesi&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Testimonial_8" class="group firer ie-background commentable non-processed" customid="Categorias" datasizewidth="585.0px" datasizeheight="760.0px" >\
        <div id="s-Bg_5" class="pie rectangle manualfit firer commentable non-processed" customid="Bg_1"   datasizewidth="585.0px" datasizeheight="487.0px" datasizewidthpx="585.0000000000002" datasizeheightpx="486.9999999999999" dataX="-624.0" dataY="278.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Categoria3" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_6" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="-581.0" dataY="567.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_6_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_19" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="113.3px" datasizeheight="32.0px" dataX="-543.0" dataY="596.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_19_0">Marketing</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_5" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="-140.0" dataY="599.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_11" class="group firer ie-background commentable non-processed" customid="Categoria2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_7" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="-581.0" dataY="445.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_7_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_20" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="80.8px" datasizeheight="32.0px" dataX="-545.0" dataY="475.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_20_0">Edici&oacute;n</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_7" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="-142.0" dataY="478.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Categoria1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_8" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="-581.0" dataY="323.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_8_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_21" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="157.4px" datasizeheight="32.0px" dataX="-545.0" dataY="346.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_21_0">Programaci&oacute;n</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_8" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="-141.0" dataY="349.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="296.2px" datasizeheight="46.0px" dataX="-479.0" dataY="694.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/a161bf55-c744-440c-a333-f8c15b0ac9a8.jpg" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Testimonial_7" class="group firer ie-background commentable non-processed" customid="Usuarios" datasizewidth="585.0px" datasizeheight="760.0px" >\
        <div id="s-Bg_1" class="pie rectangle manualfit firer commentable non-processed" customid="Bg_1"   datasizewidth="585.0px" datasizeheight="487.0px" datasizewidthpx="585.0000000000002" datasizeheightpx="486.9999999999999" dataX="-624.0" dataY="278.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Usuario3" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_4" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="-581.0" dataY="567.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_4_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_18" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="108.3px" datasizeheight="25.0px" dataX="-484.0" dataY="587.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_18_0">@cualquiera</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="-140.0" dataY="599.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="shapewrapper-s-Ellipse_4" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="40.0px" datasizeheight="40.0px" datasizewidthpx="40.0" datasizeheightpx="40.0" dataX="-553.0" dataY="586.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_4)">\
                              <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="20.0" cy="20.0" rx="20.0" ry="20.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                              <ellipse cx="20.0" cy="20.0" rx="20.0" ry="20.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_4" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_4_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Text_26" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_10"   datasizewidth="93.0px" datasizeheight="16.0px" dataX="-484.0" dataY="613.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_26_0">Ejemplo ejemplo </span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Usuario2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_3" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="-581.0" dataY="445.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_3_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_17" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="175.0px" datasizeheight="25.0px" dataX="-484.0" dataY="465.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_17_0">@miguelMaldonado</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_3" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="40.0px" datasizeheight="40.0px" datasizewidthpx="40.0" datasizeheightpx="40.0" dataX="-553.0" dataY="464.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_3)">\
                              <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="20.0" cy="20.0" rx="20.0" ry="20.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                              <ellipse cx="20.0" cy="20.0" rx="20.0" ry="20.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_3" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_3_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Text_25" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_10"   datasizewidth="113.8px" datasizeheight="16.0px" dataX="-484.0" dataY="491.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_25_0">Miguelito Maldonado</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="-142.0" dataY="478.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Usuario1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_2" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="-581.0" dataY="323.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_2_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_16" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="89.7px" datasizeheight="25.0px" dataX="-484.0" dataY="343.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_16_0">@johnKiss</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_2" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="40.0px" datasizeheight="40.0px" datasizewidthpx="40.0" datasizeheightpx="40.0" dataX="-553.0" dataY="342.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_2)">\
                              <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="20.0" cy="20.0" rx="20.0" ry="20.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                              <ellipse cx="20.0" cy="20.0" rx="20.0" ry="20.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_2" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_2_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Text_22" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_10"   datasizewidth="98.6px" datasizeheight="16.0px" dataX="-484.0" dataY="369.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_22_0">John Kiss Mart&iacute;nez</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="-141.0" dataY="349.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Image_9" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="296.2px" datasizeheight="46.0px" dataX="-479.0" dataY="694.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/a161bf55-c744-440c-a333-f8c15b0ac9a8.jpg" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;