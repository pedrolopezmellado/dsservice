var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-17efe904-2a43-49aa-93a5-cf4e89f9c588" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="listaServicios" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/17efe904-2a43-49aa-93a5-cf4e89f9c588-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/17efe904-2a43-49aa-93a5-cf4e89f9c588-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/17efe904-2a43-49aa-93a5-cf4e89f9c588-1622382714847-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Testimonial_7" class="group firer ie-background commentable non-processed" customid="Servicios" datasizewidth="585.0px" datasizeheight="760.0px" >\
        <div id="s-Bg_1" class="pie rectangle manualfit firer commentable non-processed" customid="Bg_1"   datasizewidth="585.0px" datasizeheight="487.0px" datasizewidthpx="585.0000000000002" datasizeheightpx="486.9999999999999" dataX="348.0" dataY="134.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Servicio3" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_4" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="391.0" dataY="423.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_4_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_18" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="191.9px" datasizeheight="29.0px" dataX="416.0" dataY="449.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_18_0">Ejemplo de servicio</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="832.0" dataY="452.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Servicio2" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_3" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="391.0" dataY="301.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_3_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_17" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="183.4px" datasizeheight="29.0px" dataX="416.0" dataY="327.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_17_0">Direcci&oacute;n de v&iacute;deo</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="830.0" dataY="330.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Servicio1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_2" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="500.0px" datasizeheight="78.0px" datasizewidthpx="500.0000000000002" datasizeheightpx="78.0" dataX="391.0" dataY="179.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_2_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_16" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="174.4px" datasizeheight="29.0px" dataX="416.0" dataY="205.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_16_0">Pruebas unitarias</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="830.0" dataY="208.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/4f62247a-1af5-4fd5-89b2-12fbf60e98f1.png" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="496.0px" datasizeheight="74.0px" dataX="391.0" dataY="179.0"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_9" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="296.2px" datasizeheight="64.0px" dataX="493.0" dataY="550.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/a161bf55-c744-440c-a333-f8c15b0ac9a8.jpg" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Cerrar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_18" class="pie image firer ie-background commentable non-processed" customid="Image_18"   datasizewidth="20.4px" datasizeheight="20.4px" dataX="102.0" dataY="39.0"   alt="image" systemName="./images/5d00fa14-ca70-4ec2-842e-62d5e7f3c2e6.svg" overlay="#E2202C">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>close-icon copy</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_18-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B2B2B2" id="s-Image_18-Components" transform="translate(-729.000000, -1389.000000)">\
            	            <g id="s-Image_18-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
            	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_18-Fill-1" style="fill:#E2202C !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="21.2px" datasizeheight="22.8px" dataX="102.0" dataY="37.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="671.0px" datasizeheight="67.0px" dataX="307.5" dataY="37.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Servicios</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;