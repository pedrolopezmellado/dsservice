var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-68878ff4-cff7-4d47-81c8-6c97963ebc23" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="DisputaSinResolverVistaAdmin" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/68878ff4-cff7-4d47-81c8-6c97963ebc23-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/68878ff4-cff7-4d47-81c8-6c97963ebc23-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/68878ff4-cff7-4d47-81c8-6c97963ebc23-1622382714847-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="770.0px" datasizeheight="760.0px" >\
        <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="770.0px" datasizeheight="457.0px" datasizewidthpx="770.0" datasizeheightpx="457.0" dataX="255.0" dataY="23.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="516.0px" datasizeheight="103.0px" dataX="382.0" dataY="23.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">Direcci&oacute;n de v&iacute;deo</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="695.0px" datasizeheight="98.0px" dataX="292.5" dataY="222.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Buenos d&iacute;as, hace unos d&iacute;as compr&eacute; este servicio de direcci&oacute;n de v&iacute;deo pero no he recibido ninguna respuesta por parte del vendedor. Realic&eacute; el pago pero ya no estoy interesado en el servicio. Solicito la devoluci&oacute;n de mi dinero y que esta escoria no ande por esta platoforma. Muchas gracias.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="216.0px" datasizeheight="32.0px" dataX="292.5" dataY="181.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Roberto Puche</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Cerrar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_18" class="pie image firer ie-background commentable non-processed" customid="Image_18"   datasizewidth="20.4px" datasizeheight="20.4px" dataX="102.0" dataY="39.0"   alt="image" systemName="./images/c9cbde55-d111-4bde-8823-9781307ae643.svg" overlay="#E2202C">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>close-icon copy</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_18-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B2B2B2" id="s-Image_18-Components" transform="translate(-729.000000, -1389.000000)">\
            	            <g id="s-Image_18-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
            	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_18-Fill-1" style="fill:#E2202C !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="21.2px" datasizeheight="22.8px" dataX="102.0" dataY="37.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="pie textarea firer commentable non-processed" customid="Input 1"  datasizewidth="684.5px" datasizeheight="128.0px" dataX="295.0" dataY="336.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder="Debido a (...) se resuelve que (...)"></textarea></div></div></div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer mouseenter mouseleave click commentable non-processed" customid="Rectangle_2"   datasizewidth="131.0px" datasizeheight="35.2px" datasizewidthpx="131.0" datasizeheightpx="35.20625000000001" dataX="574.5" dataY="575.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">E N V I A R</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Radiobutton" class="group firer ie-background commentable non-processed" customid="Radiobutton" datasizewidth="22.0px" datasizeheight="62.0px" >\
        <div id="shapewrapper-s-Ellipse_1" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="594.0" dataY="511.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_2" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="601.0" dataY="518.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot_1"   datasizewidth="22.0px" datasizeheight="22.0px" dataX="594.0" dataY="511.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_3" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="737.0" dataY="511.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_3)">\
                            <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer ie-background commentable non-processed" customid="Ellipse_3" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_3" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_3_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_4" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="744.0" dataY="518.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_4)">\
                            <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable hidden non-processed" customid="Ellipse_4" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                            <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_4" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_4_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot_2"   datasizewidth="22.0px" datasizeheight="22.0px" dataX="737.0" dataY="511.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="65.0px" datasizeheight="26.0px" dataX="520.0" dataY="509.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Aceptar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="80.0px" datasizeheight="26.0px" dataX="654.0" dataY="509.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Rechazar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;