var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-b87a9d11-39c1-443d-9d31-7d6d61d7ba63" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="InicioSesion" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b87a9d11-39c1-443d-9d31-7d6d61d7ba63-1622382714847.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/b87a9d11-39c1-443d-9d31-7d6d61d7ba63-1622382714847-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/b87a9d11-39c1-443d-9d31-7d6d61d7ba63-1622382714847-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="490.0px" datasizeheight="515.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="490.0px" datasizeheight="515.0px" datasizewidthpx="490.0" datasizeheightpx="515.0" dataX="395.0" dataY="119.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="360.0px" datasizeheight="38.0px" dataX="460.0" dataY="524.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">&iquest;No tienes una cuenta? </span><span id="rtr-s-Paragraph_1_1">Reg&iacute;strate</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer mouseenter mouseleave click commentable non-processed" customid="Rectangle_2"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="560.0" dataY="448.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0">E N T R A R</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_1" class="pie password firer commentable non-processed" customid="Input_1"  datasizewidth="360.0px" datasizeheight="48.0px" dataX="460.0" dataY="365.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div></div></div></div>\
        <div id="s-Input_2" class="pie email text firer commentable non-processed" customid="Input_2"  datasizewidth="360.0px" datasizeheight="48.0px" dataX="460.0" dataY="295.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="email"  value="" maxlength="100"  tabindex="-1" placeholder="Correo electr&oacute;nico"/></div></div>  </div></div></div>\
        <div id="s-Text_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="211.8px" datasizeheight="49.0px" dataX="533.0" dataY="215.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0">Inicio sesi&oacute;n</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="logo" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="32.8px" datasizeheight="53.5px" dataX="566.0" dataY="146.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/7ca866c4-2512-4d45-bbda-311d2b36a629.png" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="169.0px" datasizeheight="31.0px" dataX="604.0" dataY="163.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_3_0">DSServices</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="138.0px" datasizeheight="51.0px" dataX="565.0" dataY="147.0"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
        <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="66.0px" datasizeheight="19.0px" dataX="681.0" dataY="524.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Paragraph 2"   datasizewidth="93.0px" datasizeheight="32.0px" dataX="593.5" dataY="618.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Admin</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;