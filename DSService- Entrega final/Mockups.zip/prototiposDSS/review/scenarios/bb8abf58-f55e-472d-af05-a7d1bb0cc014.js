var content='<div id="sc-bb8abf58-f55e-472d-af05-a7d1bb0cc014" class="ui-page ui-scenario sc-bb8abf58-f55e-472d-af05-a7d1bb0cc014 commentable" name="default">\
	<link type="text/css" rel="stylesheet" href="./resources/scenarios/bb8abf58-f55e-472d-af05-a7d1bb0cc014-1622382714847.css" />\
    <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/scenarios/bb8abf58-f55e-472d-af05-a7d1bb0cc014-1622382714847-ie.css" /><![endif]-->\
    <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/scenarios/bb8abf58-f55e-472d-af05-a7d1bb0cc014-1622382714847-ie8.css" /><![endif]-->\
    <div class="filterDialog">\
      <span id="filterDialogImage"></span>\
      <span id="filterDialogTitle">Start Scenario Simulation</span>\
      <span id="filterDialogText">The prototype simulation will be restricted to the navigation defined in this scenario. You can disable this simulation by removing the filter in the top toolbar.</span>\
      <div id="filterDialogButtons">\
        <div id="startScenarioButton" class="scenarioButton">Simulate scenario</div>\
        <div id="openPageButton" class="scenarioButton">Go to screen</div>\
      </div>\
      <div id="filterCloseButton"></div>\
    </div>\
    <div class="scenarioShadow"></div>\
    <div id="scenarioWrapper">\
    </div>\
   	<div id="scenarioBgBox" ></div>\
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;