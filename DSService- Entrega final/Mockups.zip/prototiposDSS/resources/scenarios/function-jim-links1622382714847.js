(function(window, undefined) {

  var jimLinks = {
    "88ec00b4-b041-4a83-a147-a1720c02a0ff" : {
      "Hotspot_3" : [
        "0a6142bb-a038-4567-b8c3-3dda39b22820"
      ],
      "Rectangle_2" : [
        "0a6142bb-a038-4567-b8c3-3dda39b22820"
      ]
    },
    "68878ff4-cff7-4d47-81c8-6c97963ebc23" : {
      "Hotspot_3" : [
        "63282328-eba8-46f9-87f2-4f9da6c81b54"
      ],
      "Rectangle_2" : [
        "63282328-eba8-46f9-87f2-4f9da6c81b54"
      ]
    },
    "0a6142bb-a038-4567-b8c3-3dda39b22820" : {
      "Hotspot_1" : [
        "88ec00b4-b041-4a83-a147-a1720c02a0ff"
      ],
      "Hotspot_3" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ]
    },
    "63282328-eba8-46f9-87f2-4f9da6c81b54" : {
      "Hotspot_2" : [
        "68878ff4-cff7-4d47-81c8-6c97963ebc23"
      ],
      "Hotspot_3" : [
        "997cefd9-ebbc-41db-b6e0-eef0bf974324"
      ]
    },
    "729af6d4-f3ad-48a2-b61d-ca0ede12f46f" : {
      "Rectangle_2" : [
        "884f6e92-d4f7-4d41-9a0a-0a886970134a"
      ],
      "Hotspot_3" : [
        "884f6e92-d4f7-4d41-9a0a-0a886970134a"
      ]
    },
    "36c16b62-8741-440d-9f69-4647bfc70e9c" : {
      "Image_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_8" : [
        "a7ad8725-46fb-49ad-8a74-b11a596f45ca"
      ]
    },
    "dcc30c87-b721-451b-a2aa-410c00d8c3aa" : {
      "Rectangle_10" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Hotspot_3" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ]
    },
    "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d" : {
      "Hotspot_3" : [
        "997cefd9-ebbc-41db-b6e0-eef0bf974324"
      ]
    },
    "669bc1fb-85e2-4f91-af02-13d5615c8952" : {
      "Hotspot_3" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Hotspot_4" : [
        "884f6e92-d4f7-4d41-9a0a-0a886970134a"
      ],
      "Hotspot_5" : [
        "669bc1fb-85e2-4f91-af02-13d5615c8952"
      ]
    },
    "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6" : {
      "Hotspot_3" : [
        "997cefd9-ebbc-41db-b6e0-eef0bf974324"
      ]
    },
    "0dec3eab-5bb0-4e08-8a8a-03287108b145" : {
      "Rectangle_2" : [
        "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"
      ],
      "Hotspot_3" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ]
    },
    "97b23cb0-524a-4beb-9c52-e77154ced38e" : {
      "Hotspot_3" : [
        "17efe904-2a43-49aa-93a5-cf4e89f9c588"
      ]
    },
    "274236b2-1e7b-4337-b34a-e70bdac33e6a" : {
      "Hotspot_3" : [
        "9771056d-b18e-4792-a6f8-08172a3e0af6"
      ]
    },
    "cb868d11-e59f-4746-9953-2a85cc0253db" : {
      "Hotspot_1" : [
        "e7a798b8-7d57-4393-bc16-122289c56f19"
      ],
      "Hotspot_2" : [
        "cb868d11-e59f-4746-9953-2a85cc0253db"
      ],
      "Hotspot_3" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ]
    },
    "e0b550b7-1f1d-487d-b787-1ae4659050de" : {
      "Rectangle_2" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"
      ]
    },
    "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa" : {
      "Hotspot_7" : [
        "dcc30c87-b721-451b-a2aa-410c00d8c3aa"
      ],
      "Hotspot_8" : [
        "9771056d-b18e-4792-a6f8-08172a3e0af6"
      ],
      "Hotspot_4" : [
        "0dec3eab-5bb0-4e08-8a8a-03287108b145"
      ],
      "Paragraph_8" : [
        "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"
      ],
      "Hotspot_5" : [
        "669bc1fb-85e2-4f91-af02-13d5615c8952"
      ],
      "Hotspot_6" : [
        "cb868d11-e59f-4746-9953-2a85cc0253db"
      ],
      "Hotspot_10" : [
        "0a6142bb-a038-4567-b8c3-3dda39b22820"
      ],
      "Hotspot_11" : [
        "a7ad8725-46fb-49ad-8a74-b11a596f45ca"
      ]
    },
    "1d60802e-7ce2-4fab-a32b-9a1328437327" : {
      "Rectangle_2" : [
        "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"
      ],
      "Hotspot_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "19ddd0ca-d27c-4f67-b4f9-45650aaeef64" : {
      "Rectangle_2" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Hotspot_3" : [
        "0dec3eab-5bb0-4e08-8a8a-03287108b145"
      ]
    },
    "884f6e92-d4f7-4d41-9a0a-0a886970134a" : {
      "Rectangle_3" : [
        "729af6d4-f3ad-48a2-b61d-ca0ede12f46f"
      ],
      "Hotspot_3" : [
        "669bc1fb-85e2-4f91-af02-13d5615c8952"
      ],
      "Rectangle_5" : [
        "884f6e92-d4f7-4d41-9a0a-0a886970134a"
      ]
    },
    "9771056d-b18e-4792-a6f8-08172a3e0af6" : {
      "Hotspot_3" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Hotspot_1" : [
        "274236b2-1e7b-4337-b34a-e70bdac33e6a"
      ],
      "Image_3" : [
        "9771056d-b18e-4792-a6f8-08172a3e0af6"
      ]
    },
    "e7a798b8-7d57-4393-bc16-122289c56f19" : {
      "Rectangle_10" : [
        "cb868d11-e59f-4746-9953-2a85cc0253db"
      ],
      "Hotspot_3" : [
        "cb868d11-e59f-4746-9953-2a85cc0253db"
      ]
    },
    "b87a9d11-39c1-443d-9d31-7d6d61d7ba63" : {
      "Rectangle_2" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "e0b550b7-1f1d-487d-b787-1ae4659050de"
      ],
      "Paragraph_2" : [
        "997cefd9-ebbc-41db-b6e0-eef0bf974324"
      ]
    },
    "17efe904-2a43-49aa-93a5-cf4e89f9c588" : {
      "Hotspot_1" : [
        "97b23cb0-524a-4beb-9c52-e77154ced38e"
      ],
      "Hotspot_3" : [
        "997cefd9-ebbc-41db-b6e0-eef0bf974324"
      ]
    },
    "997cefd9-ebbc-41db-b6e0-eef0bf974324" : {
      "Rectangle_5" : [
        "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"
      ],
      "Rectangle_8" : [
        "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"
      ],
      "Rectangle_9" : [
        "63282328-eba8-46f9-87f2-4f9da6c81b54"
      ],
      "Rectangle_6" : [
        "17efe904-2a43-49aa-93a5-cf4e89f9c588"
      ],
      "Paragraph_8" : [
        "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"
      ]
    },
    "a7ad8725-46fb-49ad-8a74-b11a596f45ca" : {
      "Image_6" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Paragraph_3" : [
        "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"
      ],
      "Rectangle_8" : [
        "a7ad8725-46fb-49ad-8a74-b11a596f45ca"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_2" : [
        "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"
      ],
      "Hotspot_3" : [
        "e0b550b7-1f1d-487d-b787-1ae4659050de"
      ],
      "Hotspot_4" : [
        "1d60802e-7ce2-4fab-a32b-9a1328437327"
      ],
      "Hotspot_5" : [
        "36c16b62-8741-440d-9f69-4647bfc70e9c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);