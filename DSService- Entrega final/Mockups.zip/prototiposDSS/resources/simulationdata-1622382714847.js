function initData() {
  jimData.datamasters["prueba"] = [
    {
      "id": 1,
      "datamaster": "prueba",
      "userdata": {
        "5c57e11c-8152-4766-9a75-e59b2cd2be22": "Name",
        "3b3f9d70-655d-40c0-972b-49b4b925cc8f": "Company name",
        "4860374c-74fc-44e6-95eb-aef198af4524": "Lorem ipsum",
        "aafdf9d3-567d-4810-af3b-17261ea75f78": "Lorem ipsum"
      }
    },
    {
      "id": 2,
      "datamaster": "prueba",
      "userdata": {
        "5c57e11c-8152-4766-9a75-e59b2cd2be22": "Name",
        "3b3f9d70-655d-40c0-972b-49b4b925cc8f": "Company name",
        "4860374c-74fc-44e6-95eb-aef198af4524": "Lorem ipsum",
        "aafdf9d3-567d-4810-af3b-17261ea75f78": "Lorem ipsum"
      }
    },
    {
      "id": 3,
      "datamaster": "prueba",
      "userdata": {
        "5c57e11c-8152-4766-9a75-e59b2cd2be22": "Name",
        "3b3f9d70-655d-40c0-972b-49b4b925cc8f": "Company name",
        "4860374c-74fc-44e6-95eb-aef198af4524": "Lorem ipsum",
        "aafdf9d3-567d-4810-af3b-17261ea75f78": "Lorem ipsum"
      }
    },
    {
      "id": 4,
      "datamaster": "prueba",
      "userdata": {
        "5c57e11c-8152-4766-9a75-e59b2cd2be22": "Name",
        "3b3f9d70-655d-40c0-972b-49b4b925cc8f": "Company name",
        "4860374c-74fc-44e6-95eb-aef198af4524": "Lorem ipsum",
        "aafdf9d3-567d-4810-af3b-17261ea75f78": "Lorem ipsum"
      }
    },
    {
      "id": 5,
      "datamaster": "prueba",
      "userdata": {
        "5c57e11c-8152-4766-9a75-e59b2cd2be22": "Name",
        "3b3f9d70-655d-40c0-972b-49b4b925cc8f": "Company name",
        "4860374c-74fc-44e6-95eb-aef198af4524": "Lorem ipsum",
        "aafdf9d3-567d-4810-af3b-17261ea75f78": "Lorem ipsum"
      }
    },
    {
      "id": 6,
      "datamaster": "prueba",
      "userdata": {
        "5c57e11c-8152-4766-9a75-e59b2cd2be22": "Name",
        "3b3f9d70-655d-40c0-972b-49b4b925cc8f": "Company name",
        "4860374c-74fc-44e6-95eb-aef198af4524": "Lorem ipsum",
        "aafdf9d3-567d-4810-af3b-17261ea75f78": "Lorem ipsum"
      }
    },
    {
      "id": 7,
      "datamaster": "prueba",
      "userdata": {
        "5c57e11c-8152-4766-9a75-e59b2cd2be22": "Name",
        "3b3f9d70-655d-40c0-972b-49b4b925cc8f": "Company name",
        "4860374c-74fc-44e6-95eb-aef198af4524": "Lorem ipsum",
        "aafdf9d3-567d-4810-af3b-17261ea75f78": "Lorem ipsum"
      }
    }
  ];

  jimData.datamasters["jose"] = [
    {
      "id": 1,
      "datamaster": "jose",
      "userdata": {
        "a693a9bc-9a5e-4baf-bb53-fc20a11c827d": "Lorem ipsum",
        "9df3af1b-9611-49f4-9f31-c47978deeb8e": "Lorem ipsum",
        "b8035e05-0dd7-4c0f-a545-e9592f666844": "Lorem ipsum",
        "1933c0cc-a166-4a37-b723-14c7598a3148": "Lorem ipsum dolor sit amet",
        "0ca4c0b4-942c-493f-88ca-de43b973bf57": "Lorem ipsum",
        "89228ec0-80e4-4e69-a520-accf2034cf33": "Lorem ipsum dolor sit amet",
        "4b807560-3ab3-4249-883b-56d5965cdc95": "Lorem ipsum",
        "bb7a9883-a2ac-4761-b358-dccc9216ce4e": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 2,
      "datamaster": "jose",
      "userdata": {
        "a693a9bc-9a5e-4baf-bb53-fc20a11c827d": "Lorem ipsum",
        "9df3af1b-9611-49f4-9f31-c47978deeb8e": "Lorem ipsum",
        "b8035e05-0dd7-4c0f-a545-e9592f666844": "Lorem ipsum",
        "1933c0cc-a166-4a37-b723-14c7598a3148": "Lorem ipsum dolor sit amet",
        "0ca4c0b4-942c-493f-88ca-de43b973bf57": "Lorem ipsum",
        "89228ec0-80e4-4e69-a520-accf2034cf33": "Lorem ipsum dolor sit amet",
        "4b807560-3ab3-4249-883b-56d5965cdc95": "Lorem ipsum",
        "bb7a9883-a2ac-4761-b358-dccc9216ce4e": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 3,
      "datamaster": "jose",
      "userdata": {
        "a693a9bc-9a5e-4baf-bb53-fc20a11c827d": "Lorem ipsum",
        "9df3af1b-9611-49f4-9f31-c47978deeb8e": "Lorem ipsum",
        "b8035e05-0dd7-4c0f-a545-e9592f666844": "Lorem ipsum",
        "1933c0cc-a166-4a37-b723-14c7598a3148": "Lorem ipsum dolor sit amet",
        "0ca4c0b4-942c-493f-88ca-de43b973bf57": "Lorem ipsum",
        "89228ec0-80e4-4e69-a520-accf2034cf33": "Lorem ipsum dolor sit amet",
        "4b807560-3ab3-4249-883b-56d5965cdc95": "Lorem ipsum",
        "bb7a9883-a2ac-4761-b358-dccc9216ce4e": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 4,
      "datamaster": "jose",
      "userdata": {
        "a693a9bc-9a5e-4baf-bb53-fc20a11c827d": "Lorem ipsum",
        "9df3af1b-9611-49f4-9f31-c47978deeb8e": "Lorem ipsum",
        "b8035e05-0dd7-4c0f-a545-e9592f666844": "Lorem ipsum",
        "1933c0cc-a166-4a37-b723-14c7598a3148": "Lorem ipsum dolor sit amet",
        "0ca4c0b4-942c-493f-88ca-de43b973bf57": "Lorem ipsum",
        "89228ec0-80e4-4e69-a520-accf2034cf33": "Lorem ipsum dolor sit amet",
        "4b807560-3ab3-4249-883b-56d5965cdc95": "Lorem ipsum",
        "bb7a9883-a2ac-4761-b358-dccc9216ce4e": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 5,
      "datamaster": "jose",
      "userdata": {
        "a693a9bc-9a5e-4baf-bb53-fc20a11c827d": "Lorem ipsum",
        "9df3af1b-9611-49f4-9f31-c47978deeb8e": "Lorem ipsum",
        "b8035e05-0dd7-4c0f-a545-e9592f666844": "Lorem ipsum",
        "1933c0cc-a166-4a37-b723-14c7598a3148": "Lorem ipsum dolor sit amet",
        "0ca4c0b4-942c-493f-88ca-de43b973bf57": "Lorem ipsum",
        "89228ec0-80e4-4e69-a520-accf2034cf33": "Lorem ipsum dolor sit amet",
        "4b807560-3ab3-4249-883b-56d5965cdc95": "Lorem ipsum",
        "bb7a9883-a2ac-4761-b358-dccc9216ce4e": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 6,
      "datamaster": "jose",
      "userdata": {
        "a693a9bc-9a5e-4baf-bb53-fc20a11c827d": "Lorem ipsum",
        "9df3af1b-9611-49f4-9f31-c47978deeb8e": "Lorem ipsum",
        "b8035e05-0dd7-4c0f-a545-e9592f666844": "Lorem ipsum",
        "1933c0cc-a166-4a37-b723-14c7598a3148": "Lorem ipsum dolor sit amet",
        "0ca4c0b4-942c-493f-88ca-de43b973bf57": "Lorem ipsum",
        "89228ec0-80e4-4e69-a520-accf2034cf33": "Lorem ipsum dolor sit amet",
        "4b807560-3ab3-4249-883b-56d5965cdc95": "Lorem ipsum",
        "bb7a9883-a2ac-4761-b358-dccc9216ce4e": "Lorem ipsum dolor sit amet"
      }
    }
  ];

  jimData.datamasters["Prueba"] = [
    {
      "id": 1,
      "datamaster": "Prueba",
      "userdata": {
        "def6f3a8-51f2-459a-92dc-a5a3fbc11e3b": "Name",
        "db2cda00-95b9-4b4a-bd8d-3bd5cb8a5492": "Company name",
        "d295076d-b4fb-4410-a1d7-ae88530ffab2": "Lorem ipsum",
        "f768959b-f838-4ace-ba04-346f7ec47391": "Lorem ipsum"
      }
    },
    {
      "id": 2,
      "datamaster": "Prueba",
      "userdata": {
        "def6f3a8-51f2-459a-92dc-a5a3fbc11e3b": "Name",
        "db2cda00-95b9-4b4a-bd8d-3bd5cb8a5492": "Company name",
        "d295076d-b4fb-4410-a1d7-ae88530ffab2": "Lorem ipsum",
        "f768959b-f838-4ace-ba04-346f7ec47391": "Lorem ipsum"
      }
    },
    {
      "id": 3,
      "datamaster": "Prueba",
      "userdata": {
        "def6f3a8-51f2-459a-92dc-a5a3fbc11e3b": "Name",
        "db2cda00-95b9-4b4a-bd8d-3bd5cb8a5492": "Company name",
        "d295076d-b4fb-4410-a1d7-ae88530ffab2": "Lorem ipsum",
        "f768959b-f838-4ace-ba04-346f7ec47391": "Lorem ipsum"
      }
    },
    {
      "id": 4,
      "datamaster": "Prueba",
      "userdata": {
        "def6f3a8-51f2-459a-92dc-a5a3fbc11e3b": "Name",
        "db2cda00-95b9-4b4a-bd8d-3bd5cb8a5492": "Company name",
        "d295076d-b4fb-4410-a1d7-ae88530ffab2": "Lorem ipsum",
        "f768959b-f838-4ace-ba04-346f7ec47391": "Lorem ipsum"
      }
    },
    {
      "id": 5,
      "datamaster": "Prueba",
      "userdata": {
        "def6f3a8-51f2-459a-92dc-a5a3fbc11e3b": "Name",
        "db2cda00-95b9-4b4a-bd8d-3bd5cb8a5492": "Company name",
        "d295076d-b4fb-4410-a1d7-ae88530ffab2": "Lorem ipsum",
        "f768959b-f838-4ace-ba04-346f7ec47391": "Lorem ipsum"
      }
    },
    {
      "id": 6,
      "datamaster": "Prueba",
      "userdata": {
        "def6f3a8-51f2-459a-92dc-a5a3fbc11e3b": "Name",
        "db2cda00-95b9-4b4a-bd8d-3bd5cb8a5492": "Company name",
        "d295076d-b4fb-4410-a1d7-ae88530ffab2": "Lorem ipsum",
        "f768959b-f838-4ace-ba04-346f7ec47391": "Lorem ipsum"
      }
    },
    {
      "id": 7,
      "datamaster": "Prueba",
      "userdata": {
        "def6f3a8-51f2-459a-92dc-a5a3fbc11e3b": "Name",
        "db2cda00-95b9-4b4a-bd8d-3bd5cb8a5492": "Company name",
        "d295076d-b4fb-4410-a1d7-ae88530ffab2": "Lorem ipsum",
        "f768959b-f838-4ace-ba04-346f7ec47391": "Lorem ipsum"
      }
    }
  ];

  jimData.isInitialized = true;
}