(function(window, undefined) {
  var dictionary = {
    "88ec00b4-b041-4a83-a147-a1720c02a0ff": "notificacion",
    "68878ff4-cff7-4d47-81c8-6c97963ebc23": "DisputaSinResolverVistaAdmin",
    "0a6142bb-a038-4567-b8c3-3dda39b22820": "notificaciones",
    "63282328-eba8-46f9-87f2-4f9da6c81b54": "listaDisputas",
    "729af6d4-f3ad-48a2-b61d-ca0ede12f46f": "AbrirDisputa",
    "36c16b62-8741-440d-9f69-4647bfc70e9c": "aboutUsInvitado",
    "dcc30c87-b721-451b-a2aa-410c00d8c3aa": "CrearServicio",
    "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d": "listaCategorias",
    "669bc1fb-85e2-4f91-af02-13d5615c8952": "ServiciosAdquiridos",
    "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6": "listaUsuarios",
    "0dec3eab-5bb0-4e08-8a8a-03287108b145": "Servicio",
    "97b23cb0-524a-4beb-9c52-e77154ced38e": "ServicioVistaAdmin",
    "274236b2-1e7b-4337-b34a-e70bdac33e6a": "Disputa",
    "cb868d11-e59f-4746-9953-2a85cc0253db": "MisServicios",
    "e0b550b7-1f1d-487d-b787-1ae4659050de": "Registro",
    "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa": "homeRegistro",
    "1d60802e-7ce2-4fab-a32b-9a1328437327": "ServicioSinRegistro",
    "19ddd0ca-d27c-4f67-b4f9-45650aaeef64": "Comprar",
    "884f6e92-d4f7-4d41-9a0a-0a886970134a": "ServicioContratado",
    "9771056d-b18e-4792-a6f8-08172a3e0af6": "MisDisputas",
    "e7a798b8-7d57-4393-bc16-122289c56f19": "EditarServicio",
    "b87a9d11-39c1-443d-9d31-7d6d61d7ba63": "InicioSesion",
    "17efe904-2a43-49aa-93a5-cf4e89f9c588": "listaServicios",
    "997cefd9-ebbc-41db-b6e0-eef0bf974324": "homeAdministrador",
    "a7ad8725-46fb-49ad-8a74-b11a596f45ca": "aboutUsRegistrado",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "homeInvitado",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);