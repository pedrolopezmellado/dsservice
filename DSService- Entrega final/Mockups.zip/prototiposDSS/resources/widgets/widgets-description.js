	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Rectangle_4", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Blog 1", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Title 1", "s-Text_2"]; 

	widgets.descriptionMap[["s-Text_5", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Title 1", "s-Text_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Paragraph 1", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Text_3", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Title 1", "s-Text_3"]; 

	widgets.descriptionMap[["s-Image_18", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Text_6", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Title 1", "s-Text_6"]; 

	widgets.descriptionMap[["s-Ellipse_1", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Ellipse_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Hotspot_1", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Ellipse_3", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Ellipse_4", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Hotspot_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Paragraph_1", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Paragraph_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Rectangle_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "88ec00b4-b041-4a83-a147-a1720c02a0ff"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Blog 1", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Title 1", "s-Text_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Paragraph 1", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Text_3", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Title 1", "s-Text_3"]; 

	widgets.descriptionMap[["s-Image_18", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Ellipse_1", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Ellipse_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Hotspot_1", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Ellipse_3", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Ellipse_4", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Hotspot_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Paragraph_1", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Paragraph_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "68878ff4-cff7-4d47-81c8-6c97963ebc23"]] = ["Radio button", "s-Radiobutton"]; 

	widgets.descriptionMap[["s-Bg_1", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_4", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_4", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_18", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Text_18", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_3", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_17", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_2", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_16", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Hotspot_1", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_9", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_18", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "0a6142bb-a038-4567-b8c3-3dda39b22820"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Bg_1", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_4", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_4", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_18", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Text_18", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_2", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_3", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_17", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_3", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Hotspot_2", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_2", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_16", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_4", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_9", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_18", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "63282328-eba8-46f9-87f2-4f9da6c81b54"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_2", "729af6d4-f3ad-48a2-b61d-ca0ede12f46f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "729af6d4-f3ad-48a2-b61d-ca0ede12f46f"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Image_18", "729af6d4-f3ad-48a2-b61d-ca0ede12f46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "729af6d4-f3ad-48a2-b61d-ca0ede12f46f"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_8", "36c16b62-8741-440d-9f69-4647bfc70e9c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "36c16b62-8741-440d-9f69-4647bfc70e9c"]] = ["Button dark", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Rectangle_8", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_9", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_10", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Button dark", "s-Rectangle_10"]; 

	widgets.descriptionMap[["s-Input_7", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_8", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_13", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_13", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_9", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_11", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_11", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Paragraph 1", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Text_2", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Title 1", "s-Text_2"]; 

	widgets.descriptionMap[["s-Line_1", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_12", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_13", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_14", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_15", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_16", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_12", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_12", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Input field", "s-Input_12"]; 

	widgets.descriptionMap[["s-Image_2", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Chev Down", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_24", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_24", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Picture", "s-Image_24"]; 

	widgets.descriptionMap[["s-Image_25", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Picture", "s-Image_25"]; 

	widgets.descriptionMap[["s-Image_26", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_26", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Picture", "s-Image_26"]; 

	widgets.descriptionMap[["s-Image_27", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_27", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Picture", "s-Image_27"]; 

	widgets.descriptionMap[["s-Image_19", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "dcc30c87-b721-451b-a2aa-410c00d8c3aa"]] = ["Close icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Rectangle_3", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_5", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_6", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Input_1", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Input field", "s-Input_1"]; 

	widgets.descriptionMap[["s-arrow", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-arrow", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Chev Down", "s-arrow"]; 

	widgets.descriptionMap[["s-Input_2", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Search field with button", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Button dark", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Input_3", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Search field with button", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_7", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Button dark", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Image_18", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "b224f5f6-d2bc-4f50-9915-fd2a8638bf5d"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_16", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Title_3", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Title_3", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Title 1", "s-Title_3"]; 

	widgets.descriptionMap[["s-Image_27", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Image_27", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Picture", "s-Image_27"]; 

	widgets.descriptionMap[["s-Image_5", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Image_18", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_22", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_22", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_6"]; 

	widgets.descriptionMap[["s-Rectangle_23", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_23", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_6"]; 

	widgets.descriptionMap[["s-Title_11", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Title_11", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Title 1", "s-Title_11"]; 

	widgets.descriptionMap[["s-Image_4", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_6"]; 

	widgets.descriptionMap[["s-Rectangle_12", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Rectangle_13", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Title", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Title 1", "s-Title"]; 

	widgets.descriptionMap[["s-Image_3", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Hotspot_4", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Hotspot_5", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_5", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_6", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Input_1", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Input field", "s-Input_1"]; 

	widgets.descriptionMap[["s-arrow", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ""; 

			widgets.rootWidgetMap[["s-arrow", "669bc1fb-85e2-4f91-af02-13d5615c8952"]] = ["Chev Down", "s-arrow"]; 

	widgets.descriptionMap[["s-Bg_1", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_4", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_4", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_18", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_18", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_2", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_4", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_26", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_26", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_3", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_17", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_3", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_25", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_25", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_3", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_2", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_16", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_2", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_22", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_22", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_4", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_9", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_18", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "e2b12a33-0b1d-4b1c-8597-e3a4f01944f6"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Bg", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Text_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Ellipse_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Line_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Title_2", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Image_18", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Like", "s-Image_18"]; 

	widgets.descriptionMap[["s-Paragraph_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Rectangle_2", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Bg_white_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_white_1", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_18", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_19", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_20", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_21", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Image_19", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "0dec3eab-5bb0-4e08-8a8a-03287108b145"]] = ["Close icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Bg", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Text_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Ellipse_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Line_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Title_2", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Image_18", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Like", "s-Image_18"]; 

	widgets.descriptionMap[["s-Paragraph_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph_2", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Bg_white_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_white_1", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_18", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_19", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_20", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_21", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Image_19", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "97b23cb0-524a-4beb-9c52-e77154ced38e"]] = ["Close icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Rectangle_4", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Blog 1", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_2", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Title 1", "s-Text_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Paragraph 1", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Text_3", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Title 1", "s-Text_3"]; 

	widgets.descriptionMap[["s-Text_5", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Title 1", "s-Text_5"]; 

	widgets.descriptionMap[["s-Ellipse_6", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Blog 1", "s-Group_3"]; 

	widgets.descriptionMap[["s-Image_18", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Paragraph_6", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Paragraph 1", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Text_4", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "274236b2-1e7b-4337-b34a-e70bdac33e6a"]] = ["Title 1", "s-Text_4"]; 

	widgets.descriptionMap[["s-Rectangle_12", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Rectangle_13", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Title", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Title 1", "s-Title"]; 

	widgets.descriptionMap[["s-Image_3", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Rectangle_14", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_2"]; 

	widgets.descriptionMap[["s-Rectangle_15", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_2"]; 

	widgets.descriptionMap[["s-Title_2", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Image_4", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_2"]; 

	widgets.descriptionMap[["s-Rectangle_16", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Title_3", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Title_3", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Title 1", "s-Title_3"]; 

	widgets.descriptionMap[["s-Image_27", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Image_27", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Picture", "s-Image_27"]; 

	widgets.descriptionMap[["s-Image_5", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Image_18", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "cb868d11-e59f-4746-9953-2a85cc0253db"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Paragraph 1", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Input_4", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_3", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_2", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Title 1", "s-Text_1"]; 

	widgets.descriptionMap[["s-Image_4", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Hotspot_3", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "e0b550b7-1f1d-487d-b787-1ae4659050de"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_2", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Search field with button", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_5", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Zoom icon", "s-Image_5"]; 

	widgets.descriptionMap[["s-Rectangle_2", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Button dark", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Image_22", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Burger menu", "s-Image_22"]; 

	widgets.descriptionMap[["s-Hotspot_1", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Search field with button", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_12", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Rectangle_13", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Title", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title"]; 

	widgets.descriptionMap[["s-Hotspot_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Rectangle_14", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_2"]; 

	widgets.descriptionMap[["s-Rectangle_15", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_2"]; 

	widgets.descriptionMap[["s-Title_2", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Rectangle_16", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Title_3", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_3", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_3"]; 

	widgets.descriptionMap[["s-Rectangle_18", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_4"]; 

	widgets.descriptionMap[["s-Rectangle_19", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_4"]; 

	widgets.descriptionMap[["s-Title_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_4"]; 

	widgets.descriptionMap[["s-Rectangle_20", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_5"]; 

	widgets.descriptionMap[["s-Rectangle_21", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_5"]; 

	widgets.descriptionMap[["s-Title_10", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_10", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_10"]; 

	widgets.descriptionMap[["s-Rectangle_22", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_22", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_6"]; 

	widgets.descriptionMap[["s-Rectangle_23", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_23", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4_6"]; 

	widgets.descriptionMap[["s-Title_11", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_11", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_11"]; 

	widgets.descriptionMap[["s-Input_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Input field", "s-Input_4"]; 

	widgets.descriptionMap[["s-Input_8", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Input field", "s-Input_8"]; 

	widgets.descriptionMap[["s-Input_6", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_6", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Input field", "s-Input_6"]; 

	widgets.descriptionMap[["s-Image_21", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_21", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Check mark", "s-Image_21"]; 

	widgets.descriptionMap[["s-Image_20", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_20", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Close icon", "s-Image_20"]; 

	widgets.descriptionMap[["s-Rectangle_10", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Rectangle_11", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Title_1", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_1", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_1"]; 

	widgets.descriptionMap[["s-Title_5", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_5", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_5"]; 

	widgets.descriptionMap[["s-Line_26", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Line_26", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_27", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Line_27", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_28", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Line_28", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_29", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Line_29", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_30", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Line_30", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_31", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Line_31", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Title_6", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_6", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_6"]; 

	widgets.descriptionMap[["s-Title_7", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_7", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_7"]; 

	widgets.descriptionMap[["s-Title_8", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_8", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_8"]; 

	widgets.descriptionMap[["s-Title_9", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Title_9", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Title 1", "s-Title_9"]; 

	widgets.descriptionMap[["s-Image_19", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Close icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Rectangle_3", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_5", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_6", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Input_1", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Input field", "s-Input_1"]; 

	widgets.descriptionMap[["s-arrow", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ""; 

			widgets.rootWidgetMap[["s-arrow", "f89cecb0-d836-4bf8-a9cb-fd2d795f68aa"]] = ["Chev Down", "s-arrow"]; 

	widgets.descriptionMap[["s-Bg", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Text_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Ellipse_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Line_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Title_2", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Image_18", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Like", "s-Image_18"]; 

	widgets.descriptionMap[["s-Paragraph_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Rectangle_2", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Bg_white_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_white_1", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_18", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_19", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_20", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_21", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Image_19", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "1d60802e-7ce2-4fab-a32b-9a1328437327"]] = ["Close icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Rectangle_1", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Payment form 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Input_3", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Payment form 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_17", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Title 1", "s-Text_17"]; 

	widgets.descriptionMap[["s-Text_21", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Text_21", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Title 1", "s-Text_21"]; 

	widgets.descriptionMap[["s-Input_16", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Input_16", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Payment form 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_22", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Text_22", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Title 1", "s-Text_22"]; 

	widgets.descriptionMap[["s-Text_23", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Text_23", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Title 1", "s-Text_23"]; 

	widgets.descriptionMap[["s-Input_17", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Input_17", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Payment form 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_1", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Title 1", "s-Text_1"]; 

	widgets.descriptionMap[["s-Text_14", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Text_14", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Title 1", "s-Text_14"]; 

	widgets.descriptionMap[["s-Text_20", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Text_20", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Title 1", "s-Text_20"]; 

	widgets.descriptionMap[["s-Input_4", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Payment form 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_18", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Input_18", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Payment form 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_18", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "19ddd0ca-d27c-4f67-b4f9-45650aaeef64"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Bg", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Text_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Ellipse_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Line_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Title_2", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Image_18", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Like", "s-Image_18"]; 

	widgets.descriptionMap[["s-Paragraph_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Rectangle_2", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Rectangle_3", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Button dark", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Testimonial 4", "s-Testimonial_4"]; 

	widgets.descriptionMap[["s-Image_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Rating", "s-Image_1"]; 

	widgets.descriptionMap[["s-Bg_white_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_white_1", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_18", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_19", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_20", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Rectangle_21", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Portfolio 3", "s-Portfolio-3"]; 

	widgets.descriptionMap[["s-Image_19", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Close icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Rectangle_5", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "884f6e92-d4f7-4d41-9a0a-0a886970134a"]] = ["Button dark", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Image_18", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Bg_1", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_4", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_4", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_18", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_18", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_4", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_26", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_26", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_9", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_9", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_5", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_3", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_17", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_3", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_25", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_25", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_7", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_4", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_2", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_16", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_2", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_22", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_22", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_6", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Hotspot_1", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_3", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_36", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_36", "9771056d-b18e-4792-a6f8-08172a3e0af6"]] = ["User icon", "s-Image_36"]; 

	widgets.descriptionMap[["s-Rectangle_8", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_9", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_10", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Button dark", "s-Rectangle_10"]; 

	widgets.descriptionMap[["s-Input_7", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_8", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_13", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Input_13", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_9", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_11", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Input_11", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Paragraph 1", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Text_2", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Title 1", "s-Text_2"]; 

	widgets.descriptionMap[["s-Line_1", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Contact 1", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_12", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_13", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_14", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_15", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_16", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_12", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Input_12", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Input field", "s-Input_12"]; 

	widgets.descriptionMap[["s-Image_2", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Chev Down", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_24", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Image_24", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Picture", "s-Image_24"]; 

	widgets.descriptionMap[["s-Image_25", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Picture", "s-Image_25"]; 

	widgets.descriptionMap[["s-Image_26", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Image_26", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Picture", "s-Image_26"]; 

	widgets.descriptionMap[["s-Image_27", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Image_27", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Picture", "s-Image_27"]; 

	widgets.descriptionMap[["s-Image_19", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ""; 

			widgets.rootWidgetMap[["s-Image_19", "e7a798b8-7d57-4393-bc16-122289c56f19"]] = ["Close icon", "s-Image_19"]; 

	widgets.descriptionMap[["s-Rectangle_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Paragraph 1", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Input_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Title 1", "s-Text_1"]; 

	widgets.descriptionMap[["s-Image_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Hotspot_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Hotspot_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "b87a9d11-39c1-443d-9d31-7d6d61d7ba63"]] = ["Sign in form", "s-Group_1"]; 

	widgets.descriptionMap[["s-Bg_1", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_4", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_4", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_18", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Text_18", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_2", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_3", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_17", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_3", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_2", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_16", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_4", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Hotspot_1", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_9", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_18", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "17efe904-2a43-49aa-93a5-cf4e89f9c588"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_5", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Button light 2", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Rectangle_8", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Button dark", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Rectangle_9", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Button dark", "s-Rectangle_9"]; 

	widgets.descriptionMap[["s-Rectangle_6", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Button light 2", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Bg_5", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_5", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Bg_6", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_6", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Text_19", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_19", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Image_5", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Bg_7", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_7", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Text_20", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_20", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Image_7", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Bg_8", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_8", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Text_21", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_21", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Image_8", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Image_1", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_8"]; 

	widgets.descriptionMap[["s-Bg_1", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_4", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_4", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_18", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_18", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_2", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_4", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_26", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_26", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_3", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_3", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_17", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_3", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_25", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_25", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_3", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Bg_2", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_2", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_16", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Ellipse_2", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Text_22", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Text_22", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_4", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Image_9", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "997cefd9-ebbc-41db-b6e0-eef0bf974324"]] = ["Testimonial 7", "s-Testimonial_7"]; 

	widgets.descriptionMap[["s-Rectangle_8", "a7ad8725-46fb-49ad-8a74-b11a596f45ca"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "a7ad8725-46fb-49ad-8a74-b11a596f45ca"]] = ["Button dark", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search field with button", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Zoom icon", "s-Image_5"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button dark", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Image_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Burger menu", "s-Image_22"]; 

	widgets.descriptionMap[["s-Hotspot_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search field with button", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Rectangle_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_1"]; 

	widgets.descriptionMap[["s-Title", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title"]; 

	widgets.descriptionMap[["s-Rectangle_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_2"]; 

	widgets.descriptionMap[["s-Rectangle_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_2"]; 

	widgets.descriptionMap[["s-Title_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Rectangle_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_3"]; 

	widgets.descriptionMap[["s-Title_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_3"]; 

	widgets.descriptionMap[["s-Rectangle_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Rectangle_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Title_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_1"]; 

	widgets.descriptionMap[["s-Title_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_5"]; 

	widgets.descriptionMap[["s-Line_26", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Line_26", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_27", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Line_27", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_28", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Line_28", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_29", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Line_29", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_30", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Line_30", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Line_31", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Line_31", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4"]; 

	widgets.descriptionMap[["s-Title_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_6"]; 

	widgets.descriptionMap[["s-Title_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_7"]; 

	widgets.descriptionMap[["s-Title_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_8"]; 

	widgets.descriptionMap[["s-Title_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_9"]; 

	widgets.descriptionMap[["s-Image_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_4"]; 

	widgets.descriptionMap[["s-Rectangle_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_4"]; 

	widgets.descriptionMap[["s-Title_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_4"]; 

	widgets.descriptionMap[["s-Rectangle_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_5"]; 

	widgets.descriptionMap[["s-Rectangle_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_5"]; 

	widgets.descriptionMap[["s-Title_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_10"]; 

	widgets.descriptionMap[["s-Rectangle_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_6"]; 

	widgets.descriptionMap[["s-Rectangle_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Data list 3", "s-Data-table-4_6"]; 

	widgets.descriptionMap[["s-Title_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Title_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title 1", "s-Title_11"]; 

	widgets.descriptionMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dropdown menu", "s-Dropdown"]; 

	widgets.descriptionMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input field", "s-Input_1"]; 

	widgets.descriptionMap[["s-arrow", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-arrow", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Chev Down", "s-arrow"]; 

	